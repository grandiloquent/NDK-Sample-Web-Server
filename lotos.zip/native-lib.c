#include <jni.h>
#include "server.h"
#include "lotos_epoll.h"

#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>

int set_static_directory() {
    DIR *dirp = NULL;
    if (server_config.rootdir != NULL &&
        (dirp = opendir(server_config.rootdir)) != NULL) {
        closedir(dirp);
        server_config.rootdir_fd = open(server_config.rootdir, O_RDONLY);
        ERR_ON(server_config.rootdir_fd == ERROR, server_config.rootdir);
        return OK;
    } else {
        perror(server_config.rootdir);
        return ERROR;
    }
}

void start_server(const char *dir) {
    server_config.rootdir = dir;
    server_setup(8089);
    int nfds;
    int i;
    while (1) {
        nfds = lotos_epoll_wait(epoll_fd, lotos_events, MAX_EVENTS, 20);
        if (nfds == ERROR) {
            ERR_ON(errno != EINTR, "lotos_epoll_wait");
        }
        for (i = 0; i < nfds; i++) {
            struct epoll_event *curr_event = lotos_events + i;
            int fd = *((int *) (curr_event->data.ptr));
            if (fd == listen_fd) {
                server_accept(listen_fd);
            } else {
                connection_t *c = curr_event->data.ptr;
                int status;
                if (connecion_is_expired(c))continue;
                if (curr_event->events & EPOLLIN) {
                    status = request_handle(c);
                    if (status == ERROR)
                        connecion_set_expired(c);
                    else
                        connecion_set_reactivated(c);
                }
                if (curr_event->events & EPOLLOUT) {
                    status = response_handle(c);
                    if (status == ERROR)
                        connecion_set_expired(c);
                    else
                        connecion_set_reactivated(c);
                }
            }
        }
        connection_prune();
    }
    close(epoll_fd);
    server_shutdown();

}

JNIEXPORT jint JNICALL
Java_euphoria_psycho_server_MainActivity_startServer(JNIEnv *env, jclass type, jstring host_,
                                                     jint port, jstring staticDirectory_) {
    const char *host = (*env)->GetStringUTFChars(env, host_, 0);
    const char *staticDirectory = (*env)->GetStringUTFChars(env, staticDirectory_, 0);

    start_server(staticDirectory);
    (*env)->ReleaseStringUTFChars(env, host_, host);
    (*env)->ReleaseStringUTFChars(env, staticDirectory_, staticDirectory);

    return 0;
}